<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

include('conexao.php');

if (!isset($_POST['id']) || empty($_POST['id'])) {
    header("Location: listar.php?msg=produto_nao_encontrado");
    exit;
}

$id = intval($_POST['id']);

try {
    // Verifica se o produto existe
    $stmt = $conn->prepare("SELECT id FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        header("Location: listar.php?msg=produto_nao_encontrado");
        exit;
    }

    // Apaga movimentações vinculadas ao produto
    $stmt = $conn->prepare("DELETE FROM movimentacoes WHERE produto_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // Agora exclui o produto
    $stmt = $conn->prepare("DELETE FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: listar.php?msg=produto_excluido");
    exit;

} catch (Exception $e) {
    echo "<h3>Erro:</h3><pre>" . $e->getMessage() . "</pre>";
    exit;
}
?>
