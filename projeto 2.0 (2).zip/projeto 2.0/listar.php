<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

include('conexao.php');
$usuario_id = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];

// Mensagem de retorno via GET
$mensagem = "";
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case "produto_excluido":
            $mensagem = "<p class='mensagem'>✅ Produto excluído com sucesso!</p>";
            break;
        case "erro_excluir_produto":
            $mensagem = "<p class='erro'>❌ Erro ao excluir o produto! Verifique se há movimentações vinculadas.</p>";
            break;
        case "fornecedor_excluido":
            $mensagem = "<p class='mensagem'>✅ Fornecedor excluído com sucesso!</p>";
            break;
        case "erro_excluir_fornecedor":
            $mensagem = "<p class='erro'>❌ Erro ao excluir o fornecedor! Verifique se há produtos vinculados.</p>";
            break;
        case "produto_nao_encontrado":
            $mensagem = "<p class='erro'>❌ Produto não encontrado!</p>";
            break;
        case "fornecedor_nao_encontrado":
            $mensagem = "<p class='erro'>❌ Fornecedor não encontrado!</p>";
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8" />
    <title>Produtos em Estoque</title>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

/* ===== Fundo com efeito animado ===== */
body {
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    min-height: 100vh;
    display: block;
    justify-content: center;
    align-items: flex-start;
    padding: 60px 0;
    position: relative;
    overflow-y: auto; /* ✅ Scroll ativado */
}

/* ===== Brilho animado no fundo ===== */
.background-glow {
    position: fixed;
    width: 350px;
    height: 350px;
    background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
    top: 15%;
    left: 25%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 65%;
    left: 60%;
    background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
}

@keyframes pulse {
    from { transform: scale(1); opacity: 0.8; }
    to { transform: scale(1.2); opacity: 1; }
}

/* ===== Container principal ===== */
.container {
    background: rgba(31, 31, 31, 0.9);
    backdrop-filter: blur(8px);
    padding: 40px 35px;
    border-radius: 16px;
    width: 100%;
    max-width: 1200px;
    margin: 0 auto 100px auto;
    box-shadow: 0 0 25px rgba(0,0,0,0.6);
    border: 1px solid rgba(255,255,255,0.08);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ===== Cabeçalho ===== */
h2 {
    font-size: 28px;
    text-align: center;
    color: #fff;
    margin-bottom: 25px;
    letter-spacing: 1px;
}

/* ===== Top Bar (botões de ação) ===== */
.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 25px;
    gap: 12px;
}

.top-bar div {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

/* ===== Botões principais ===== */
.btn-cadastrar,
.btn-logout,
.btn-historico,
.btn-cadastrar-fornecedor,
.botao-inicio {
    padding: 12px 20px;
    border-radius: 8px;
    border: none;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s ease;
    color: #fff;
    display: inline-block;
    box-shadow: 0 4px 15px rgba(0,0,0,0.4);
}

/* Azul - Cadastrar Produto */
.btn-cadastrar {
    background: linear-gradient(90deg, #007bff, #0066cc);
}
.btn-cadastrar:hover {
    background: linear-gradient(90deg, #339dff, #007bff);
    transform: translateY(-3px);
}

/* Roxo - Cadastrar Fornecedor */
.btn-cadastrar-fornecedor {
    background: linear-gradient(90deg, #6f42c1, #5a32a3);
}
.btn-cadastrar-fornecedor:hover {
    background: linear-gradient(90deg, #7d55d1, #6f42c1);
    transform: translateY(-3px);
}

/* Verde - Histórico */
.btn-historico {
    background: linear-gradient(90deg, #28a745, #218838);
}
.btn-historico:hover {
    background: linear-gradient(90deg, #38c757, #28a745);
    transform: translateY(-3px);
}

/* Vermelho - Logout */
.btn-logout {
    background: linear-gradient(90deg, #ff4b4b, #cc3939);
}
.btn-logout:hover {
    background: linear-gradient(90deg, #ff6666, #ff4b4b);
    transform: translateY(-3px);
}

/* Cinza - Voltar ao Início */
.botao-inicio {
    background: linear-gradient(90deg, #6c757d, #5a6268);
}
.botao-inicio:hover {
    background: linear-gradient(90deg, #868e96, #6c757d);
    transform: translateY(-3px);
}

/* ===== Tabela de Estoque ===== */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 14px 10px;
    text-align: center;
    border-bottom: 1px solid #333;
    font-size: 15px;
}

th {
    background: rgba(45, 45, 45, 0.9);
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

tr {
    transition: background 0.3s ease;
}
tr:hover {
    background: rgba(51, 51, 51, 0.9);
}

/* ===== Ações (editar/excluir) ===== */
.acoes a {
    color: #007bff;
    text-decoration: none;
    font-weight: 600;
    margin: 0 5px;
    transition: 0.3s;
}
.acoes a:hover {
    text-decoration: underline;
    color: #339dff;
}

/* ===== Mensagens ===== */
.mensagem {
    text-align: center;
    font-weight: bold;
    color: limegreen;
    margin-bottom: 15px;
}
.erro {
    text-align: center;
    font-weight: bold;
    color: #ff4b4b;
    margin-bottom: 15px;
}

/* ===== Responsividade ===== */
@media (max-width: 992px) {
    .container {
        padding: 30px 20px;
        max-width: 95%;
    }
    th, td {
        padding: 10px;
        font-size: 14px;
    }
    .top-bar {
        flex-direction: column;
        align-items: stretch;
    }
    .top-bar div {
        justify-content: center;
    }
}


</style>


</head>

<body>
    <div class="container">
        <div class="top-bar">
            <h2>Produtos em Estoque</h2>
            <div>
                <a href="index.php" class="botao botao-inicio">🏠 Início</a>
                <a class="btn-cadastrar" href="cadastrar.php">➕ Cadastrar Produto</a>
                <a class="btn-cadastrar-fornecedor" href="cadastrar_fornecedor.php">➕ Cadastrar Fornecedor</a>
                <a class="btn-cadastrar-fornecedor" href="movimentar_estoque.php" style="background:#ff9800;">📦 Movimentar Estoque</a>
                <a class="btn-historico" href="historico.php">📜 Histórico</a>
                <a class="btn-logout" href="logout.php">🚪 Sair</a>
            </div>
        </div>

        <?php echo $mensagem; ?>

        <!-- LISTA DE PRODUTOS -->
        <table>
            <tr>
                <th>ID</th>
                <th>Nome do Produto</th>
                <th>Código</th>
                <th>Descrição</th>
                <th>Quantidade</th>
                <th>Preço</th>
                <th>Fornecedor</th>
                <th>Ações</th>
            </tr>
            <?php
            $sql = "SELECT p.*, f.nome AS fornecedor_nome 
                    FROM produtos p 
                    LEFT JOIN fornecedores f ON p.fornecedor_id = f.id 
                    WHERE p.usuario_id = $usuario_id 
                    ORDER BY p.id DESC";

            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>" . htmlspecialchars($row['nome']) . "</td>
                            <td>" . htmlspecialchars($row['codigo']) . "</td>
                            <td>" . htmlspecialchars($row['descricao']) . "</td>
                            <td>{$row['quantidade']}</td>
                            <td>R$ " . number_format($row['preco'], 2, ',', '.') . "</td>
                            <td>" . htmlspecialchars($row['fornecedor_nome'] ?? 'Sem fornecedor') . "</td>
                            <td class='acoes'>
                                <a href='editar.php?id={$row['id']}'> Editar</a> | 
                                <a href='confirmar_exclusao.php?id={$row['id']}'> Excluir</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>Nenhum produto encontrado.</td></tr>";
            }
            ?>
        </table>

<!-- LISTA DE FORNECEDORES -->
<h2 style="margin-top:40px;">Fornecedores</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>CNPJ</th>
        <th>Telefone</th>
        <th>Email</th>
        <th>Endereço</th>
        <th>Ações</th>
    </tr>
    <?php
    $sql_f = "SELECT * FROM fornecedores WHERE usuario_id = $usuario_id ORDER BY id DESC";
    $result_f = $conn->query($sql_f);

    if ($result_f->num_rows > 0) {
        while ($f = $result_f->fetch_assoc()) {
            echo "<tr>
                    <td>{$f['id']}</td>
                    <td>" . htmlspecialchars($f['nome']) . "</td>
                    <td>" . htmlspecialchars($f['cnpj']) . "</td>
                    <td>" . htmlspecialchars($f['telefone']) . "</td>
                    <td>" . htmlspecialchars($f['email']) . "</td>
                    <td>" . htmlspecialchars($f['endereco']) . "</td>
                    <td class='acoes'>
                        <a href='excluir_fornecedor.php?id={$f['id']}' onclick=\"return confirm('Deseja realmente excluir este fornecedor?');\"> Excluir</a>
                    </td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='7'>Nenhum fornecedor cadastrado.</td></tr>";
    }
    ?>
</table>

    </div>
</body>

</html>
