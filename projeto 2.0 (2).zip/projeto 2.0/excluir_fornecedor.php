<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

include('conexao.php');
$usuario_id = $_SESSION['usuario_id'];

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Verificar se existe algum produto vinculado a esse fornecedor
    $sql_check = "SELECT COUNT(*) as total FROM produtos WHERE fornecedor_id = ? AND usuario_id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("ii", $id, $usuario_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();
    $row_check = $result_check->fetch_assoc();

    if ($row_check['total'] > 0) {
        // Tem produto vinculado, não pode excluir
        $stmt_check->close();
        $conn->close();
        header("Location: listar.php?msg=erro_excluir_fornecedor");
        exit;
    }

    $stmt_check->close();

    // Se não tem produto vinculado, pode excluir
    $sql = "DELETE FROM fornecedores WHERE id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $usuario_id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        header("Location: listar.php?msg=fornecedor_excluido");
    } else {
        header("Location: listar.php?msg=fornecedor_nao_encontrado");
    }

    $stmt->close();
    $conn->close();
} else {
    // ID não passado
    header("Location: listar.php?msg=fornecedor_nao_encontrado");
    exit;
}
?>
