<?php
session_start();
if(!isset($_SESSION['usuario_id'])){
    header("Location: index.php");
    exit;
}

include('conexao.php');

$usuario_id = $_SESSION['usuario_id'];
$mensagem = "";

// Buscar fornecedores cadastrados
$fornecedores = $conn->query("SELECT * FROM fornecedores ORDER BY nome");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $codigo = $_POST['codigo'];
    $descricao = $_POST['descricao'];
    $quantidade = $_POST['quantidade'];
    $preco = $_POST['preco'];
    $fornecedor_id = $_POST['fornecedor'];

    // Inserir produto
    $usuario_id = $_SESSION['usuario_id'];
    $sql = "INSERT INTO produtos (nome, codigo, descricao, quantidade, preco, fornecedor_id, usuario_id)
        VALUES ('$nome', '$codigo', '$descricao', '$quantidade', '$preco', '$fornecedor_id', '$usuario_id')";


    if ($conn->query($sql) === TRUE) {
        $produto_id = $conn->insert_id;

        // Registrar movimentação de entrada
        $sql_mov = "INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade)
                    VALUES ($produto_id, $usuario_id, 'entrada', $quantidade)";
        $conn->query($sql_mov);

        $mensagem = "<p class='mensagem'>✅ Produto cadastrado com sucesso!</p>";
    } else {
        $mensagem = "<p class='erro'>❌ Erro ao cadastrar: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Cadastrar Produto</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

/* ===== Fundo animado e moderno ===== */
body {
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    font-family: "Poppins", sans-serif;
    margin: 0;
    padding: 50px 0; /* espaço no topo e embaixo */
    min-height: 100vh;
    overflow-y: auto; /* permite rolagem */
    position: relative;
}

/* Efeitos de luz de fundo */
.background-glow {
    position: fixed; /* muda para fixed, assim o fundo não rola com a página */
    width: 320px;
    height: 320px;
    background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
    top: 15%;
    left: 20%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 65%;
    left: 60%;
    background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
}

/* container com z-index pra ficar acima do brilho */
.container {
    background: rgba(30, 30, 30, 0.9);
    backdrop-filter: blur(8px);
    padding: 40px 35px;
    border-radius: 16px;
    width: 90%;
    max-width: 600px;
    margin: 0 auto 80px auto; /* centraliza e dá espaçamento inferior */
    box-shadow: 0 0 25px rgba(0,0,0,0.6);
    border: 1px solid rgba(255,255,255,0.08);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}


@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ===== Título ===== */
h2 {
    font-size: 28px;
    margin-bottom: 20px;
    text-align: center;
    color: #fff;
}

/* ===== Formulário ===== */
form {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

label {
    text-align: left;
    font-size: 14px;
    color: #ccc;
    font-weight: 500;
}

/* ===== Inputs e Select ===== */
input, select, textarea {
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #444;
    background: #2a2a2a;
    color: #fff;
    font-size: 15px;
    transition: 0.2s;
}

input:focus, select:focus, textarea:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0,123,255,0.5);
    outline: none;
}

textarea {
    resize: vertical;
    min-height: 60px;
}

/* ===== Botão ===== */
.btn {
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: linear-gradient(90deg, #007bff, #0066cc);
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0,123,255,0.3);
}

.btn:hover {
    background: linear-gradient(90deg, #339dff, #007bff);
    transform: translateY(-3px);
}

/* ===== Mensagens ===== */
.mensagem {
    text-align: center;
    font-weight: bold;
    color: limegreen;
    margin-bottom: 15px;
}

.erro {
    text-align: center;
    font-weight: bold;
    color: #ff4b4b;
    margin-bottom: 15px;
}

/* ===== Link Voltar ===== */
.link-voltar {
    display: inline-block;
    margin-top: 15px;
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
    transition: 0.2s;
    text-align: center;
}

.link-voltar:hover {
    color: #339dff;
    text-decoration: underline;
}

</style>
</head>
<body>
<div class="container">
<h2>Cadastro de Produtos</h2>
<?php echo $mensagem; ?>
<form method="POST" action="">
    <label>Nome do Produto:</label>
    <input type="text" name="nome" required>

    <label>Código do Produto:</label>
    <input type="text" name="codigo" required>

    <label>Descrição:</label>
    <textarea name="descricao" required></textarea>

    <label>Quantidade em Estoque:</label>
    <input type="number" name="quantidade" required>

    <label>Preço Unitário (R$):</label>
    <input type="text" name="preco" required>

    <label>Fornecedor:</label>
    <select name="fornecedor" required>
        <option value="">Selecione um fornecedor</option>
        <?php
        if ($fornecedores->num_rows > 0) {
            while ($f = $fornecedores->fetch_assoc()) {
                echo "<option value='{$f['id']}'>{$f['nome']}</option>";
            }
        } else {
            echo "<option disabled>Nenhum fornecedor cadastrado</option>";
        }
        ?>
    </select>

    <button type="submit" class="btn">Cadastrar Produto</button>
</form>

<a href="listar.php" class="link-voltar">⬅ Voltar para o Estoque</a>
</div>
</body>
</html>
