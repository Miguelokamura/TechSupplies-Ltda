<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('conexao.php');

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"]);
    $senha = trim($_POST["senha"]);

    if ($email === "" || $senha === "") {
        $mensagem = "Por favor, preencha email e senha.";
    } else {
        $stmt = $conn->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ? LIMIT 1");
        if ($stmt === false) {
            $mensagem = "Erro ao preparar consulta: " . htmlspecialchars($conn->error);
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado && $resultado->num_rows === 1) {
                $usuario = $resultado->fetch_assoc();

                if (password_verify($senha, $usuario["senha"])) {
                    $_SESSION["usuario_id"] = $usuario["id"];
                    $_SESSION["usuario_nome"] = $usuario["nome"];

                    header("Location: listar.php");
                    exit;
                } else {
                    $mensagem = "Senha incorreta.";
                }
            } else {
                $mensagem = "Usuário não encontrado.";
            }

            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

/* === Fundo moderno com brilho animado === */
body {
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    font-family: 'Poppins', sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    position: relative;
    overflow: hidden;
}

/* Efeitos de brilho do fundo */
.background-glow {
    position: absolute;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
    top: 15%;
    left: 20%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 60%;
    left: 60%;
    background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
}

@keyframes pulse {
    from { transform: scale(1); opacity: 0.8; }
    to { transform: scale(1.2); opacity: 1; }
}

/* === Container principal === */
.container {
    background: rgba(31, 31, 31, 0.9);
    backdrop-filter: blur(8px);
    padding: 30px 35px;
    border-radius: 16px;
    width: 100%;
    max-width: 420px;
    box-shadow: 0 6px 25px rgba(0, 0, 0, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.08);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}

/* Animação de entrada suave */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* === Textos e inputs === */
h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #fff;
}

label {
    display: block;
    margin-top: 10px;
    color: #ccc;
    font-weight: 500;
}

input {
    width: 100%;
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #444;
    background: #2a2a2a;
    color: #fff;
    margin-top: 5px;
    font-size: 14px;
    box-sizing: border-box;
    transition: 0.2s;
}

input:focus {
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0,123,255,0.5);
}

/* === Botões === */
button {
    margin-top: 20px;
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: linear-gradient(90deg, #007bff, #0066cc);
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    font-weight: 500;
    box-shadow: 0 4px 15px rgba(0,123,255,0.3);
    transition: all 0.3s ease;
}

button:hover {
    background: linear-gradient(90deg, #339dff, #007bff);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0,123,255,0.4);
}

/* === Mensagens e links === */
.mensagem {
    text-align: center;
    margin-top: 15px;
    color: #ff4b4b;
    font-weight: 600;
}

.info {
    text-align: center;
    margin-top: 10px;
    color: #ccc;
    font-size: 14px;
}

a {
    color: #007bff;
    text-decoration: none;
    display: block;
    text-align: center;
    margin-top: 15px;
    transition: 0.2s;
}

a:hover {
    text-decoration: underline;
}


    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>

        <?php if ($mensagem): ?>
            <p class="mensagem"><?php echo htmlspecialchars($mensagem); ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <label>Email:</label>
            <input type="email" name="email" required autofocus>

            <label>Senha:</label>
            <input type="password" name="senha" required>

            <button type="submit">Entrar</button>
        </form>

        <!-- Link de registro removido / desativado conforme sua preferência -->
        <!-- <p class="info">Não tem conta? <a href="registro.php">Registrar</a></p> -->
    </div>
</body>
</html>
