<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('conexao.php');

$usuario_id = $_SESSION['usuario_id'];
$mensagem = "";

// Buscar produtos para o select
$sqlProdutos = "SELECT id, nome FROM produtos WHERE usuario_id = ?";
$stmtProdutos = $conn->prepare($sqlProdutos);
$stmtProdutos->bind_param("i", $usuario_id);
$stmtProdutos->execute();
$resultProdutos = $stmtProdutos->get_result();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produto_id = $_POST['produto_id'] ?? null;
    $tipo = $_POST['tipo'] ?? null; // 'entrada' ou 'saida'
    $quantidade = $_POST['quantidade'] ?? null;
    $data_hora = $_POST['data_hora'] ?? null;

    // Validações básicas
    if (!$produto_id || !in_array($tipo, ['entrada', 'saida']) || !$quantidade || !$data_hora) {
        $mensagem = "<p class='erro'>❌ Preencha todos os campos corretamente.</p>";
    } elseif (!is_numeric($quantidade) || $quantidade <= 0) {
        $mensagem = "<p class='erro'>❌ Quantidade deve ser um número positivo.</p>";
    } else {
        // Verifica se produto pertence ao usuário
        $sqlVerifica = "SELECT quantidade FROM produtos WHERE id = ? AND usuario_id = ?";
        $stmtVerifica = $conn->prepare($sqlVerifica);
        $stmtVerifica->bind_param("ii", $produto_id, $usuario_id);
        $stmtVerifica->execute();
        $resultVerifica = $stmtVerifica->get_result();

        if ($resultVerifica->num_rows === 0) {
            $mensagem = "<p class='erro'>❌ Produto não encontrado ou sem permissão.</p>";
        } else {
            $produtoAtual = $resultVerifica->fetch_assoc();
            $quantidadeAtual = (int)$produtoAtual['quantidade'];
            $quantidadeMov = (int)$quantidade;

            if ($tipo == 'saida' && $quantidadeMov > $quantidadeAtual) {
                $mensagem = "<p class='erro'>❌ Quantidade insuficiente no estoque para saída.</p>";
            } else {
                // Começa a transação para garantir integridade
                $conn->begin_transaction();

                try {
                    // Atualiza quantidade no produto
                    if ($tipo == 'entrada') {
                        $novaQuantidade = $quantidadeAtual + $quantidadeMov;
                    } else { // saida
                        $novaQuantidade = $quantidadeAtual - $quantidadeMov;
                    }

                    $sqlAtualiza = "UPDATE produtos SET quantidade = ? WHERE id = ? AND usuario_id = ?";
                    $stmtAtualiza = $conn->prepare($sqlAtualiza);
                    $stmtAtualiza->bind_param("iii", $novaQuantidade, $produto_id, $usuario_id);
                    $stmtAtualiza->execute();

                    // Insere movimentação
                    $sqlInsert = "INSERT INTO movimentacoes (produto_id, usuario_id, tipo, quantidade, data_hora) VALUES (?, ?, ?, ?, ?)";
                    $stmtInsert = $conn->prepare($sqlInsert);
                    $stmtInsert->bind_param("iisis", $produto_id, $usuario_id, $tipo, $quantidadeMov, $data_hora);
                    $stmtInsert->execute();

                    $conn->commit();
                    header("Location: listar.php?msg=movimentacao_sucesso");
                    exit;
                } catch (Exception $e) {
                    $conn->rollback();
                    $mensagem = "<p class='erro'>❌ Erro ao movimentar estoque: " . $e->getMessage() . "</p>";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8" />
<title>Movimentar Estoque</title>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

* { 
    margin: 0; 
    padding: 0; 
    box-sizing: border-box; 
    font-family: 'Poppins', sans-serif;
}

/* === Fundo moderno com degradê e brilhos === */
body {
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    min-height: 100vh;
    display: block; /* ✅ permite rolagem natural */
    justify-content: center;
    align-items: flex-start;
    padding: 60px 0;
    position: relative;
    overflow-y: auto; /* ✅ scroll ativado */
    overflow-x: hidden;
}

/* === Brilhos animados de fundo === */
.background-glow {
    position: fixed;
    width: 350px;
    height: 350px;
    background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
    top: 15%;
    left: 20%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 65%;
    left: 60%;
    background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
}

@keyframes pulse {
    from { transform: scale(1); opacity: 0.8; }
    to { transform: scale(1.2); opacity: 1; }
}

/* === Container principal === */
.container {
    background: rgba(30, 30, 30, 0.9);
    backdrop-filter: blur(8px);
    padding: 40px 35px;
    border-radius: 16px;
    width: 100%;
    max-width: 520px;
    margin: 0 auto 80px auto;
    box-shadow: 0 0 25px rgba(0, 0, 0, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.08);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}

/* Animação de entrada suave */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* === Título === */
h2 { 
    font-size: 28px; 
    margin-bottom: 25px; 
    text-align: center; 
    color: #fff; 
    letter-spacing: 0.5px;
}

/* === Formulário === */
form { 
    display: flex; 
    flex-direction: column; 
    gap: 15px; 
}

label { 
    text-align: left; 
    font-size: 14px; 
    color: #ccc; 
    font-weight: 500; 
}

/* === Campos de entrada === */
input, select, textarea { 
    padding: 12px; 
    border-radius: 8px; 
    border: 1px solid #444; 
    background: #2a2a2a; 
    color: #fff; 
    font-size: 15px; 
    transition: all 0.2s ease;
}

input:focus, select:focus, textarea:focus { 
    border-color: #007bff; 
    box-shadow: 0 0 5px rgba(0,123,255,0.5); 
    outline: none;
}

/* === Botão principal === */
button.btn {
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: linear-gradient(90deg, #007bff, #0066cc);
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0,123,255,0.3);
}

button.btn:hover { 
    background: linear-gradient(90deg, #339dff, #007bff);
    transform: translateY(-3px);
    box-shadow: 0 6px 20px rgba(0,123,255,0.4);
}

/* === Mensagens === */
.mensagem { 
    text-align: center; 
    font-weight: bold; 
    color: limegreen; 
    margin-bottom: 15px; 
}

.erro { 
    text-align: center; 
    font-weight: bold; 
    color: #ff4b4b; 
    margin-bottom: 15px; 
}

/* === Link de voltar === */
.link-voltar { 
    display: block; 
    text-align: center; 
    margin-top: 20px; 
    color: #007bff; 
    text-decoration: none; 
    transition: color 0.3s ease;
}

.link-voltar:hover { 
    text-decoration: underline; 
    color: #339dff;
}

/* === Responsividade === */
@media (max-width: 600px) {
    .container {
        padding: 30px 25px;
        max-width: 90%;
    }
    h2 { font-size: 24px; }
    button.btn { font-size: 15px; padding: 12px; }
}


</style>
</head>
<body>
<div class="container">
    <h2>Movimentar Estoque</h2>

    <?php echo $mensagem; ?>

    <form method="POST" action="">
        <label>Produto:</label>
        <select name="produto_id" required>
            <option value="">Selecione o produto</option>
            <?php
            while ($produto = $resultProdutos->fetch_assoc()) {
                echo "<option value='{$produto['id']}'>" . htmlspecialchars($produto['nome']) . "</option>";
            }
            ?>
        </select>

        <label>Tipo de Movimentação:</label>
        <select name="tipo" required>
            <option value="">Selecione</option>
            <option value="entrada">Entrada</option>
            <option value="saida">Saída</option>
        </select>

        <label>Quantidade:</label>
        <input type="number" name="quantidade" min="1" required>

        <label>Data e Hora da Movimentação:</label>
        <input type="datetime-local" name="data_hora" required value="<?php echo date('Y-m-d\TH:i'); ?>">

        <button type="submit" class="btn">Registrar Movimentação</button>
    </form>

    <a href="listar.php" class="link-voltar">⬅ Voltar para Estoque</a>
</div>
</body>
</html>
