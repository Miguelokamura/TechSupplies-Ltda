<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

include('conexao.php');

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: listar.php?msg=produto_nao_encontrado");
    exit;
}

$id = intval($_GET['id']);

// Verifica se produto existe
$stmt = $conn->prepare("SELECT nome FROM produtos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    header("Location: listar.php?msg=produto_nao_encontrado");
    exit;
}

$produto = $res->fetch_assoc();

// Verifica se o produto tem movimentações
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM movimentacoes WHERE produto_id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$vinculo = $stmt->get_result()->fetch_assoc();

$temMovimentacoes = $vinculo['total'] > 0;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Confirmar Exclusão</title>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    position: relative;
    overflow: hidden;
}

/* === Fundo com brilhos === */
.background-glow {
    position: absolute;
    width: 320px;
    height: 320px;
    background: radial-gradient(circle, rgba(220, 53, 69, 0.3) 0%, transparent 70%);
    top: 15%;
    left: 25%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 60%;
    left: 60%;
    background: radial-gradient(circle, rgba(0, 123, 255, 0.25) 0%, transparent 70%);
}

@keyframes pulse {
    from { transform: scale(1); opacity: 0.8; }
    to { transform: scale(1.2); opacity: 1; }
}

/* === Caixa principal === */
.box {
    background: rgba(42, 42, 42, 0.9);
    padding: 30px 40px;
    border-radius: 12px;
    text-align: center;
    max-width: 500px;
    width: 90%;
    box-shadow: 0 0 25px rgba(0, 0, 0, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.08);
    backdrop-filter: blur(8px);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* === Título e texto === */
h2 {
    margin-bottom: 20px;
    font-weight: 600;
}

.warning {
    color: #ffcc00;
    font-weight: bold;
    margin-bottom: 20px;
}

/* === Botões === */
.buttons {
    display: flex;
    justify-content: center;
    gap: 20px;
}

.btn {
    padding: 12px 25px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 16px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
}

/* Botão confirmar */
.btn-confirm {
    background: linear-gradient(90deg, #dc3545, #b02a37);
    color: white;
}
.btn-confirm:hover {
    background: linear-gradient(90deg, #e85c68, #dc3545);
    transform: translateY(-2px);
}

/* Botão cancelar */
.btn-cancel {
    background: linear-gradient(90deg, #6c757d, #5a6268);
    color: white;
}
.btn-cancel:hover {
    background: linear-gradient(90deg, #8d99a2, #6c757d);
    transform: translateY(-2px);
}

    </style>
</head>
<body>
    <div class="box">
        <h2>Confirmar Exclusão</h2>
        <p>Você está prestes a excluir o produto:</p>
        <h3><?= htmlspecialchars($produto['nome']) ?></h3>

        <?php if ($temMovimentacoes): ?>
            <p class="warning">
                ⚠️ Atenção: este produto possui movimentações vinculadas.<br>
                Ao excluir o produto, todas as movimentações relacionadas também serão apagadas.
            </p>
        <?php else: ?>
            <p>Tem certeza que deseja excluir este produto?</p>
        <?php endif; ?>

        <div class="buttons">
            <form method="post" action="excluir.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $id ?>">
                <button type="submit" class="btn btn-confirm">Sim, excluir</button>
            </form>
            <a href="listar.php" class="btn btn-cancel">Cancelar</a>
        </div>
    </div>
</body>
</html>
