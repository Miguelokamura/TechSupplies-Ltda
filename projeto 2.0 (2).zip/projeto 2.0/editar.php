<?php
include('conexao.php');

// Verifica se o ID foi enviado na URL
if (!isset($_GET['id'])) {
    die("ID do produto não especificado.");
}

$id = intval($_GET['id']); // Garante que seja um número inteiro

// Busca os dados atuais do produto
$sql = "SELECT * FROM produtos WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Produto não encontrado.");
}

$produto = $result->fetch_assoc();

// Variável para mensagem de sucesso
$mensagem = "";

// Se o formulário foi enviado (método POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $categoria = $_POST['categoria'];
    $quantidade = $_POST['quantidade'];
    $preco = $_POST['preco'];
    $descricao = $_POST['descricao'];

    $sql_update = "UPDATE produtos 
                   SET nome = '$nome',
                       categoria = '$categoria',
                       quantidade = '$quantidade',
                       preco = '$preco',
                       descricao = '$descricao'
                   WHERE id = $id";

    if ($conn->query($sql_update) === TRUE) {
        $mensagem = "✅ Produto atualizado com sucesso!";
    } else {
        $mensagem = "❌ Erro ao atualizar: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Editar Produto</title>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

/* === Fundo moderno com efeito de brilho === */
body {
  background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
  color: #fff;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding-top: 50px;
  min-height: 100vh;
  position: relative;
  overflow: auto;
}

/* === Efeitos de luz no fundo === */
.background-glow {
  position: absolute;
  width: 320px;
  height: 320px;
  background: radial-gradient(circle, rgba(111, 66, 193, 0.35) 0%, transparent 70%);
  top: 20%;
  left: 25%;
  border-radius: 50%;
  filter: blur(120px);
  z-index: 0;
  animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
  top: 60%;
  left: 60%;
  background: radial-gradient(circle, rgba(0, 123, 255, 0.25) 0%, transparent 70%);
}

@keyframes pulse {
  from { transform: scale(1); opacity: 0.8; }
  to { transform: scale(1.2); opacity: 1; }
}

/* === Container principal === */
.container {
  background: rgba(31, 31, 31, 0.9);
  padding: 40px 35px;
  border-radius: 12px;
  width: 100%;
  max-width: 450px;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(8px);
  position: relative;
  z-index: 1;
  animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* === Títulos e Formulário === */
h2 {
  font-size: 28px;
  text-align: center;
  margin-bottom: 25px;
  color: #fff;
}

form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

label {
  font-size: 14px;
  color: #ccc;
  font-weight: 500;
}

input,
select,
textarea {
  padding: 12px;
  border-radius: 8px;
  border: 1px solid #444;
  background: #2a2a2a;
  color: #fff;
  font-size: 15px;
  transition: 0.2s;
  resize: vertical;
}

input:focus,
select:focus,
textarea:focus {
  border-color: #339dff;
  box-shadow: 0 0 5px rgba(0,123,255,0.3);
  outline: none;
}

/* === Botão === */
button.btn {
  padding: 14px;
  border-radius: 8px;
  border: none;
  background: linear-gradient(90deg, #339dff, #0066cc);
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(0,123,255,0.3);
}

button.btn:hover {
  background: linear-gradient(90deg, #339dff, #007bff);
  transform: translateY(-2px);
}

/* === Mensagens === */
.mensagem {
  text-align: center;
  font-weight: bold;
  margin-bottom: 15px;
}

.mensagem.sucesso {
  color: limegreen;
}

.mensagem.erro {
  color: #ff4b4b;
}

/* === Links === */
a {
  color: #007bff;
  text-decoration: none;
  transition: 0.2s;
  text-align: center;
  display: block;
  margin-top: 15px;
}

a:hover {
  color: #8256d4;
}


</style>
</head>
<body>
<div class="container">
    <h2>Editar Produto</h2>

    <?php if ($mensagem): ?>
        <p class="mensagem <?= strpos($mensagem, '✅') !== false ? 'sucesso' : 'erro' ?>">
            <?= $mensagem ?>
        </p>
    <?php endif; ?>

    <form method="POST" action="">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required>

        <label>Categoria:</label>
        <select name="categoria" required>
            <option value="Celular" <?= $produto['categoria'] == 'Celular' ? 'selected' : '' ?>>Celular</option>
            <option value="Acessório" <?= $produto['categoria'] == 'Acessório' ? 'selected' : '' ?>>Acessório</option>
        </select>

        <label>Quantidade:</label>
        <input type="number" name="quantidade" value="<?= $produto['quantidade'] ?>" required>

        <label>Preço:</label>
        <input type="text" name="preco" value="<?= $produto['preco'] ?>" required>

        <label>Descrição:</label>
        <textarea name="descricao"><?= htmlspecialchars($produto['descricao']) ?></textarea>

        <button type="submit" class="btn"> Confirmar Edição</button>
    </form>

    <a href="listar.php">⬅ Voltar para o Estoque</a>
</div>
</body>
</html>
