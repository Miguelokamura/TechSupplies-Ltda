<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

include('conexao.php');
$mensagem = "";
$usuario_id = $_SESSION['usuario_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim($_POST['nome']);
    $cnpj = trim($_POST['cnpj']);
    $telefone = trim($_POST['telefone']);
    $email = trim($_POST['email']);
    $endereco = trim($_POST['endereco']);

    // Inserir fornecedor com CNPJ
    $sql = "INSERT INTO fornecedores (nome, cnpj, telefone, email, endereco, usuario_id) 
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $nome, $cnpj, $telefone, $email, $endereco, $usuario_id);

    if ($stmt->execute()) {
        header("Location: listar.php?msg=fornecedor_cadastrado");
        exit;
    } else {
        $mensagem = "<p class='erro'>❌ Erro ao cadastrar: " . $stmt->error . "</p>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Fornecedor</title>
        <style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

/* ===== Fundo com efeito animado ===== */
body {
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    min-height: 100vh;
    display: block;
    justify-content: center;
    align-items: flex-start;
    padding: 60px 0;
    position: relative;
    overflow-y: auto; /* permite scroll */
}

/* ===== Brilho animado ===== */
.background-glow {
    position: fixed;
    width: 320px;
    height: 320px;
    background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
    top: 15%;
    left: 20%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 65%;
    left: 60%;
    background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
}

@keyframes pulse {
    from { transform: scale(1); opacity: 0.8; }
    to { transform: scale(1.2); opacity: 1; }
}

/* ===== Container principal ===== */
.container {
    background: rgba(30, 30, 30, 0.9);
    backdrop-filter: blur(8px);
    padding: 40px 35px;
    border-radius: 16px;
    width: 100%;
    max-width: 600px;
    margin: 0 auto 100px auto;
    box-shadow: 0 0 25px rgba(0,0,0,0.6);
    border: 1px solid rgba(255,255,255,0.08);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}

/* ===== Animação suave ===== */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

/* ===== Textos ===== */
h2 {
    font-size: 28px;
    margin-bottom: 25px;
    text-align: center;
    color: #fff;
}

/* ===== Formulário ===== */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    font-size: 14px;
    color: #ccc;
    font-weight: 500;
    text-align: left;
}

/* ===== Inputs e Textareas ===== */
input, select, textarea {
    padding: 12px;
    border-radius: 8px;
    border: 1px solid #444;
    background: #2a2a2a;
    color: #fff;
    font-size: 15px;
    transition: 0.2s;
    resize: vertical;
}

input:focus, select:focus, textarea:focus {
    border-color: #007bff;
    box-shadow: 0 0 6px rgba(0,123,255,0.5);
    outline: none;
}

/* ===== Botões ===== */
button.btn {
    padding: 14px;
    border-radius: 8px;
    border: none;
    background: linear-gradient(90deg, #007bff, #0066cc);
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(0,123,255,0.3);
}

button.btn:hover {
    background: linear-gradient(90deg, #339dff, #007bff);
    transform: translateY(-3px);
}

/* ===== Mensagens ===== */
.mensagem {
    text-align: center;
    font-weight: bold;
    margin-bottom: 15px;
}

.mensagem.sucesso {
    color: limegreen;
}

.mensagem.erro {
    color: #ff4b4b;
}

/* ===== Link voltar ===== */
.link-voltar {
    display: block;
    text-align: center;
    margin-top: 20px;
    color: #007bff;
    text-decoration: none;
    transition: 0.3s;
}

.link-voltar:hover {
    text-decoration: underline;
}


    </style>
</head>
<body>
<div class="container">
    <h2>Cadastro de Fornecedor</h2>
    <?php echo $mensagem; ?>
<form method="POST" action="">
    <label>Nome:</label>
    <input type="text" name="nome" required placeholder="Ex: João Silva Representações LTDA">

    <label for="cnpj">CNPJ:</label>
    <input type="text" name="cnpj" id="cnpj" required placeholder="00.000.000/0000-00">

    <label>Telefone:</label>
    <input type="text" name="telefone" placeholder="(00) 00000-0000">

    <label>Email:</label>
    <input type="email" name="email" placeholder="exemplo@email.com">

    <label>Endereço:</label>
    <textarea name="endereco" placeholder="Ex: Rua das Flores, 123 - Centro, São Paulo - SP"></textarea>

    <button type="submit" class="btn">Cadastrar Fornecedor</button>
</form>


    <a href="listar.php" class="link-voltar">⬅ Voltar para Estoque</a>
</div>

</body>
</html>
