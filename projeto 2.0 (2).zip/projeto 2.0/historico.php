<?php
session_start();
if(!isset($_SESSION['usuario_id'])){
    header("Location: index.php");
    exit;
}

include('conexao.php');
$usuario_id = $_SESSION['usuario_id'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Histórico de Movimentações</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

/* === Fundo moderno com brilho animado === */
body {
    background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
    color: #fff;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding-top: 50px;
    position: relative;
    overflow: auto;
}

/* Efeitos de brilho no fundo */
.background-glow {
    position: absolute;
    width: 350px;
    height: 350px;
    background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
    top: 20%;
    left: 25%;
    border-radius: 50%;
    filter: blur(120px);
    z-index: 0;
    animation: pulse 8s infinite alternate ease-in-out;
}

.background-glow:nth-child(2) {
    top: 60%;
    left: 60%;
    background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
}

@keyframes pulse {
    from { transform: scale(1); opacity: 0.8; }
    to { transform: scale(1.2); opacity: 1; }
}

/* === Container === */
.container {
    background: rgba(31, 31, 31, 0.9);
    backdrop-filter: blur(8px);
    padding: 40px 35px;
    border-radius: 12px;
    width: 100%;
    max-width: 1000px;
    box-shadow: 0 4px 25px rgba(0, 0, 0, 0.6);
    border: 1px solid rgba(255, 255, 255, 0.08);
    position: relative;
    z-index: 1;
    animation: fadeIn 1s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

h2 {
    font-size: 28px;
    margin-bottom: 20px;
    text-align: center;
    color: #fff;
}

/* === Tabela === */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid #333;
}

th {
    background: rgba(42, 42, 42, 0.9);
    color: #fff;
}

tr:hover {
    background: rgba(51, 51, 51, 0.9);
}

/* === Tipo de movimentação === */
.tipo-entrada {
    color: limegreen;
    font-weight: bold;
}

.tipo-saida {
    color: #ff4b4b;
    font-weight: bold;
}

/* === Botão de voltar === */
.btn-voltar {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 18px;
    background: linear-gradient(90deg, #007bff, #0066cc);
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
    transition: all 0.3s ease;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.4);
}

.btn-voltar:hover {
    background: linear-gradient(90deg, #339dff, #007bff);
    transform: translateY(-2px);
}

</style>
</head>
<body>
<div class="container">
<h2>Histórico de Movimentações</h2>

<table>
<tr>
<th>Produto</th>
<th>Usuário</th>
<th>Tipo</th>
<th>Quantidade</th>
<th>Data e Hora</th>
</tr>

<?php
$sql = "SELECT m.*, p.nome AS produto_nome, u.nome AS usuario_nome
        FROM movimentacoes m
        JOIN produtos p ON m.produto_id = p.id
        JOIN usuarios u ON m.usuario_id = u.id
        ORDER BY m.data_hora DESC";

$result = $conn->query($sql);

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $tipo_class = $row['tipo'] == 'entrada' ? 'tipo-entrada' : 'tipo-saida';
        echo "<tr>
                <td>{$row['produto_nome']}</td>
                <td>{$row['usuario_nome']}</td>
                <td class='$tipo_class'>{$row['tipo']}</td>
                <td>{$row['quantidade']}</td>
                <td>{$row['data_hora']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>Nenhuma movimentação registrada.</td></tr>";
}
?>
</table>

<a href="listar.php" class="btn-voltar">⬅ Voltar</a>
</div>
</body>
</html>
