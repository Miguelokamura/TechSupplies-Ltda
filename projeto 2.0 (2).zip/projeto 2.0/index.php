<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Estoque - Início</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2b2b2b, #1b1b1b);
            color: #f0f0f0;
            overflow: hidden;
        }

        .container {
            background: rgba(30, 30, 30, 0.9);
            backdrop-filter: blur(8px);
            padding: 50px 60px;
            border-radius: 16px;
            width: 100%;
            max-width: 480px;
            text-align: center;
            box-shadow: 0 0 25px rgba(0, 0, 0, 0.6);
            animation: fadeIn 1s ease-in-out;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .icon {
            font-size: 50px;
            color: #007bff;
            margin-bottom: 10px;
        }

        h1 {
            font-weight: 600;
            font-size: 26px;
            color: #fff;
            margin-bottom: 15px;
        }

        p {
            color: #bbb;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 35px;
        }

        .botao {
            background: linear-gradient(90deg, #007bff, #0066cc);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 14px 45px;
            font-size: 16px;
            font-weight: 500;
            text-decoration: none;
            letter-spacing: 0.5px;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.3);
            transition: all 0.3s ease;
            display: inline-block;
        }

        .botao:hover {
            background: linear-gradient(90deg, #339dff, #007bff);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 123, 255, 0.4);
        }

        footer {
            position: fixed;
            bottom: 12px;
            width: 100%;
            text-align: center;
            color: #888;
            font-size: 14px;
            letter-spacing: 0.3px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* efeito de brilho animado no fundo */
        .background-glow {
            position: absolute;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(0,123,255,0.3) 0%, transparent 70%);
            top: 15%;
            left: 20%;
            border-radius: 50%;
            filter: blur(120px);
            z-index: 0;
            animation: pulse 8s infinite alternate ease-in-out;
        }

        .background-glow:nth-child(2) {
            top: 60%;
            left: 60%;
            background: radial-gradient(circle, rgba(0,123,255,0.25) 0%, transparent 70%);
        }

        @keyframes pulse {
            from { transform: scale(1); opacity: 0.8; }
            to { transform: scale(1.2); opacity: 1; }
        }
    </style>
</head>
<body>

    <div class="background-glow"></div>
    <div class="background-glow"></div>

    <div class="container">
        <div class="icon">📱</div>
        <h1>Sistema de Estoque</h1>
        <p>Bem-vindo ao painel de controle de celulares e acessórios.<br>
        Gerencie produtos, fornecedores e estoque com agilidade e precisão.</p>
        <a href="login.php" class="botao">Acessar Sistema</a>
    </div>

    <footer>
        <p>© 2025 CellStore - Sistema de Controle de Estoque</p>
    </footer>

</body>
</html>
