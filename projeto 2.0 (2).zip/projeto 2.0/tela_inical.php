<?php
session_start();
include('conexao.php');

// Buscar produtos cadastrados
$sql = "SELECT p.*, f.nome AS fornecedor_nome 
        FROM produtos p 
        LEFT JOIN fornecedores f ON p.fornecedor_id = f.id 
        ORDER BY p.id DESC";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NZ dos iPhones</title>

  <link rel="stylesheet" href="index.css">
  <link rel="shortcut icon" href="fotos/eeeee.png" type="image/x-icon">

  <!-- Fonte clean -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
</head>

<body>

  <!-- Banner de aviso -->
  <footer class="footer-banner">
    <p>🚛 COMPRE AGORA COM FRETE GRÁTIS 🚛</p>
  </footer>

  <!-- Cabeçalho -->
  <header>
    <div class="header-left">
      <!-- Logo com link -->
      <a href="index.html" class="logo">
        <img src="fundos/logo2.jpg" alt="Logo" class="logo-img">
        <span>Nz iPhones</span>
      </a>

      <!-- Barra de pesquisa -->
      <form class="search-bar">
        <input type="text" placeholder="Buscar...">
        <button type="submit">🔍</button>
      </form>
    </div>

    <!-- Navegação centralizada -->
    <nav>
      <ul>
        <li><a href="lançamento.html" style="text-decoration: none; color: inherit;">Lançamentos</a></li>
        <li><a href="iphones.html" style="text-decoration: none; color: inherit;">iPhone</a></li>
        <li><a href="relogio.html" style="text-decoration: none; color: inherit;">Apple Watch</a></li>
        <li><a href="fones.html" style="text-decoration: none; color: inherit;">AirPods</a></li>
        <li><a href="notbook.html" style="text-decoration: none; color: inherit;">MacBook</a></li>
        <li><a href="computador.html" style="text-decoration: none; color: inherit;">iMac Apple</a></li>
      </ul>
    </nav>

    <!-- Botões de Login e Cadastro -->
<div class="auth-buttons">
<?php if(isset($_SESSION['usuario_nome'])): ?>
    <span>Olá, <?php echo $_SESSION['usuario_nome']; ?>!</span>
    <a href="logout.php" class="btn-login">Sair</a>
<?php else: ?>
    <a href="login.php" class="btn-login">Login</a>
    <a href="registro.php" class="btn-cadastro">Cadastro</a>
<?php endif; ?>
</div>

  </header>

  <!-- Título da seção -->
  <h2 class="titulo-secao">Lançamentos</h2>

  <!-- Fundo transparente maior -->
  <div class="bg-semitransparente">
    <img src="fundos/funo.jpg" alt="Plano de fundo">
  </div>

  <!-- Rodapé final -->
  <footer class="footer-main">
    <p>© 2025 Nz iPhones - Todos os direitos reservados</p>
  </footer>

</body>
</html>