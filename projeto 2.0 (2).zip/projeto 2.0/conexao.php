<?php
date_default_timezone_set('America/Sao_Paulo');

$host = "127.0.0.1:3306";
$usuario = "root";
$senha = "Senai@118";
$banco = "estoque_db";

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
